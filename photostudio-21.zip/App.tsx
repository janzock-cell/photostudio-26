import React, { useState, useRef, useEffect } from 'react';
import ImageUploader from './components/ImageUploader';
import ResultDisplay from './components/ResultDisplay';
import Spinner from './components/Spinner';
import ZoomModal from './components/ZoomModal';
import SaveOptionsModal from './components/SaveOptionsModal';
import CropModal from './components/CropModal';
import AdjustmentPanel, { Adjustments } from './components/AdjustmentPanel';
import MakeupPanel, { MakeupState } from './components/MakeupPanel';
import { analyzeImage, editImage } from './services/geminiService';
import type { BatchResult, GeminiResult } from './types';

// Declare window interface for API Key selection
declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }
  interface Window {
    aistudio?: AIStudio;
  }
}

const EDIT_KEYWORDS = [
  'edit', 'change', 'add', 'remove', 'make', 'replace', 'insert', 'put', 'apply', 'transform', 'adjust', 'give', 'enhance', 'generate', 'create', 'convert', 'style', 'retouch', 'retouching', 'swap', 'background',
  'bearbeiten', 'ändern', 'hinzufügen', 'entfernen', 'machen', 'ersetzen', 'einfügen', 'anwenden', 'transformieren', 'anpassen', 'geben', 'verbessern', 'generieren', 'erstellen', 'konvertieren', 'stil', 'retusche', 'retuschieren', 'austauschen', 'hintergrund', 'umgebung',
  'porträt', 'nahaufnahme', 'bild', 'foto', 'look', 'farbe', 'make-up', 'makeup', 'schwarzweiß', 'monochrom', 'filmkorn', 'vignette', 'szene'
];

// --- DATA: CATEGORIES SPLIT ---

const BEAUTY_CATEGORIES: Record<string, { name: string, prompt: string }[]> = {
    "High-End Retusche": [
        { name: 'Frequenztrennung (Haut)', prompt: 'Bearbeite die Haut: Wende eine Frequenztrennung an. Behalte die Porenstruktur und feinen Details zu 100% bei. Korrigiere nur sanft Rötungen. Das Bild muss gestochen scharf bleiben.' },
        { name: 'Dodge & Burn (Tiefe)', prompt: 'Bearbeite das Gesicht: Verwende Dodge & Burn, um die Gesichtszüge plastisch herauszuarbeiten. Verstärke Highlights auf Wangenknochen und Nasenrücken, vertiefe sanft die Schatten.' },
        { name: 'Strahlende Augen', prompt: 'Bearbeite die Augen: Erhöhe Helligkeit und Sättigung der Iris leicht, schärfe Details und setze ein klares Glanzlicht (Catchlight). Das Augenweiß soll natürlich wirken.' },
        { name: 'Zähne aufhellen', prompt: 'Bearbeite die Zähne: Helle sie natürlich auf. Entferne Gelbstich, aber vermeide künstliches "Hollywood-Weiß". Es muss zur Lichtstimmung passen.' },
    ],
    "Lifestyle & Look": [
        { name: 'Golden Hour Glow', prompt: 'Ändere die Beleuchtung: Simuliere "Golden Hour" Licht. Weiches, warmes Licht von der Seite, goldener Schimmer auf der Haut. Das Bild soll warm wirken.' },
        { name: 'Clean Girl Aesthetic', prompt: 'Ändere den Look zu "Clean Girl": Minimalistisches, frisches Aussehen. Glowy Skin, gekämmte Augenbrauen, kaum Make-up. Helle, neutrale Farben.' },
        { name: 'Business Headshot', prompt: 'Verwandle das Bild in ein LinkedIn-Profilfoto: Neutraler, freundlicher Ausdruck. Mache den Hintergrund leicht unscharf (Bokeh). Gleiche die Beleuchtung für einen seriösen Studio-Look aus.' },
    ],
};

const CREATIVE_CATEGORIES: Record<string, { name: string, prompt: string }[]> = {
    "Cinematic Locations": [
        { name: 'Cyberpunk City', prompt: 'Tausche den Hintergrund aus: Setze die Person in eine dunkle Cyberpunk-Stadt bei Nacht (Neonlicht, Regen). WICHTIG: Behalte die Person exakt so bei, wie sie ist. Passe nur die Beleuchtung/Reflexionen auf der Haut an die Neonlichter an.' },
        { name: 'Vintage Eckladen', prompt: 'Ändere den Hintergrund: Platziere die Person vor einen Vintage-Laden mit warmem Schaufensterlicht. Behalte Kleidung und Gesichtszüge zu 100% bei. Stimmung: Gemütlich, sanfte Kontraste.' },
        { name: 'NYC Golden Hour', prompt: 'Ersetze den Hintergrund durch eine belebte NYC-Straße zur Goldenen Stunde (unscharfe Taxis, Stadtlichter). Behalte die Person im Vordergrund gestochen scharf. Integriere sie photorealistisch in das neue Licht.' },
        { name: 'Moving Train', prompt: 'Ändere die Szene: Die Person steht vor einem fahrenden Zug (bewegungsunscharf). Füge Filmkorn und "Golden Hour" Licht hinzu. Behalte das Gesicht unverändert bei.' },
        { name: 'Motorrad Gasse', prompt: 'Platziere die Person in eine nächtliche Stadtgasse mit einem geparkten Motorrad im Hintergrund. Beleuchtung: Starkes Seitenlicht, lange Schatten, kühle Blautöne. Person bleibt identisch.' },
    ],
    "Editorial & Fashion": [
        { name: 'Opera House', prompt: 'Setze die Person in ein glamouröses Opernhaus-Foyer (Kronleuchter, Gold). Lichtstimmung: Warm, luxuriös, glitzernd. Behalte die Person und ihr Outfit exakt bei, passe nur das Ambient-Licht an.' },
        { name: 'Gothic Cathedral', prompt: 'Tausche den Hintergrund gegen eine gotische Kathedrale aus (alter Stein, dramatisches Sonnenlicht, Lens Flare). WICHTIG: Die Frau und ihr Kleid bleiben UNVERÄNDERT. Integriere sie nur durch Licht und Schatten in die neue Umgebung.' },
        { name: 'Studio Rot/Grün', prompt: 'Ändere den Hintergrund zu reinweiß. Setze die Person auf einen roten skulpturalen Stuhl (falls sitzend) oder daneben. Färbe die Kleidung NICHT um, außer es wird explizit verlangt. Stil: Minimalistisches Mode-Editorial.' },
        { name: 'Regenszene (Nacht)', prompt: 'Füge Regen und Dunkelheit hinzu: Eine nächtliche Szene unter einer Straßenlaterne. Die Person wird von der Laterne beleuchtet. Nasse Texturen auf dem Boden. Gesicht bleibt unverändert.' },
        { name: 'Retro 90s Flair', prompt: 'Wende einen 90er Jahre Filter an: Körnige Textur, hoher Kontrast, Blitzlicht-Ästhetik. Hintergrund abdunkeln. Der Look soll wie ein Vintage-Magazin wirken.' },
    ],
    "Surreal & Fantasy": [
        { name: 'Stitched Doll', prompt: 'Bearbeite das Gesicht (Creative Makeup): Gotischer Puppen-Look. Blasse Haut, künstlerisch aufgemalte Nähte. Hintergrund: Mystischer blauer Nebel.' },
        { name: 'Slasher Mask', prompt: 'Füge eine Requisite hinzu: Die Person hält eine Vintage-Hockeymaske (Slasher-Stil). Rauchige Augen, düsterer Hintergrund. Kontrast zwischen Schönheit und Bedrohung.' },
        { name: 'Underwater Sunlight', prompt: 'Ändere die Umgebung: Die Szene spielt unter Wasser. Gebrochene Sonnenlichtmuster auf dem Gesicht, schwebende Luftblasen. Ätherisch, ruhig. Haare schweben leicht.' },
        { name: 'Underwater World', prompt: 'Ändere die Umgebung: Die Szene spielt unter Wasser. Kreative Lichteffekte im Gesicht, schwebende Luftblasen. Ätherisch, ruhig. Haare schweben leicht. Und kleine Fische und ein paar große Fische schwimmen umher. Hintergrund: Aus dem trüben Wasser im Hintergrund kommt ein riesiger Hai. Farbanpassung, 50mm, Schatten, Drei-Punkt-Beleuchtung.' },
        { name: 'Goldfischglas', prompt: 'Surreale Montage: Platziere die Person schwimmend in einem riesigen Goldfischglas. Lichtbrechungen, Wasser, Goldfische. Photorealistischer Stil.' },
        { name: 'Blumenhaar', prompt: 'Verwandle die Haare in einen Blumenstrauß (Vergissmeinnicht, Kornblume, Sternblumen, Wachsblumen, Pfingstrosen, Schleierkraut, kleine Röschen, Kamille, Olivenzweige, Lavendel, Kirschblüten). Das Gesicht bleibt unverändert. Hintergrund: Sanftes Gartengrün.' },
    ],
    "Atmosphere & FX": [
        { name: 'Magische Atmosphäre', prompt: 'Füge Effekte hinzu: Leichter Nebel, glühende Partikel, magische Lichtstimmung. Die Person bleibt natürlich.' },
        { name: 'Prisma & Light Leaks', prompt: 'Lege Filter darüber: Prismatische Regenbogen-Reflexionen und Light Leaks (Lichteinfall) an den Rändern. Analoger Foto-Look.' },
    ],
    "Berufe & Rollen": [
        { name: 'Ärztin', prompt: 'Kleidung ändern: Ziehe der Person einen weißen Arztkittel an, Stethoskop um den Hals. Hintergrund: Helles, sauberes Krankenhaus/Praxis. Gesicht bleibt identisch.' },
        { name: 'Kellnerin', prompt: 'Kleidung ändern: Kellnerin-Uniform mit Schürze. Hintergrund: Ein geschäftiges Diner. Ausdruck: Professionell.' },
    ],
};

const hairSuggestions = [
    { name: 'Blondierung', prompt: 'Färbe die Haare blond, aber behalte die Frisur und Struktur bei.' },
    { name: 'Dunkelbraun', prompt: 'Färbe die Haare in ein sattes Dunkelbraun.' },
    { name: 'Silbergrau', prompt: 'Färbe die Haare in ein modernes Silbergrau/Weiß.' },
    { name: 'Rötlich/Kupfer', prompt: 'Gib den Haaren einen natürlichen rötlichen Kupferstich.' },
    { name: 'Bunte Strähnen', prompt: 'Füge einige dezente pastellfarbene Strähnen in die Haare ein.' },
];

// --- TYPES & DEFAULTS ---

interface ImageItem {
  file: File | null;
  url: string;
  name: string;
}

interface AppHistoryState {
  images: ImageItem[];
  results: BatchResult[];
  prompt: string;
  adjustments: Adjustments;
  makeup: MakeupState;
  appMode: 'beauty' | 'creative';
}

interface ZoomedImageState {
    src: string;
    originalSrc?: string;
}

const DEFAULT_ADJUSTMENTS: Adjustments = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  vibrance: 0,
  structure: 0,
  faceLight: 0,
  dodge: 0,
  burn: 0,
};

const DEFAULT_MAKEUP: MakeupState = {
  lashes: '',
  eyeliner: '',
  lipstick: '',
  eyeshadow: '',
  blush: '',
  skin: ''
};

const cleanErrorMessage = (error: any): string => {
    let msg = error.message || "Ein unerwarteter Fehler ist aufgetreten.";
    try {
        if (typeof msg === 'string' && msg.trim().startsWith('{')) {
            const parsed = JSON.parse(msg);
            if (parsed.error && parsed.error.message) {
                msg = parsed.error.message;
            }
        }
    } catch (e) { /* ignore */ }

    if (msg.includes("403") || msg.includes("PERMISSION_DENIED")) return "Zugriff verweigert. API-Key prüfen.";
    if (msg.includes("400") || msg.includes("INVALID_ARGUMENT")) return "Bildformat nicht unterstützt oder zu groß.";
    if (msg.includes("429") || msg.includes("RESOURCE_EXHAUSTED")) return "Zu viele Anfragen. Kurze Pause bitte.";
    if (msg.includes("SAFETY") || msg.includes("Safety") || msg.includes("Sicherheit")) return "Sicherheitsfilter hat angeschlagen. Bitte Prompt ändern.";
    if (msg.includes("PROHIBITED") || msg.includes("IMAGE_OTHER") || msg.includes("Inhalt")) return "Inhaltsfilter aktiv (Copyright/Safety). Versuche eine generischere Beschreibung.";
    
    return msg;
};

type PanelMode = 'adjustments' | 'makeup';
type AppMode = 'beauty' | 'creative';

const App: React.FC = () => {
  // State
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [appMode, setAppMode] = useState<AppMode>('beauty');
  const [images, setImages] = useState<ImageItem[]>([]);
  const [prompt, setPrompt] = useState<string>('');
  const [adjustments, setAdjustments] = useState<Adjustments>(DEFAULT_ADJUSTMENTS);
  const [makeup, setMakeup] = useState<MakeupState>(DEFAULT_MAKEUP);
  const [activePanel, setActivePanel] = useState<PanelMode>('makeup');
  
  const [results, setResults] = useState<BatchResult[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [processingStatus, setProcessingStatus] = useState<string | null>(null);
  const [zoomedImage, setZoomedImage] = useState<ZoomedImageState | null>(null);
  const [saveModalData, setSaveModalData] = useState<{ url: string; originalFileName: string } | null>(null);
  const [imageToCrop, setImageToCrop] = useState<{ url: string; index: number; fileName: string; } | null>(null);
  const [hasApiKey, setHasApiKey] = useState<boolean>(false);

  // History state
  const [history, setHistory] = useState<AppHistoryState[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const isRestoringHistory = useRef(false);

  const promptTextareaRef = useRef<HTMLTextAreaElement>(null);
  const objectUrlsRef = useRef<string[]>([]);
  
  useEffect(() => {
    saveStateToHistory({ images, results, prompt, adjustments, makeup, appMode });
    return () => {
      objectUrlsRef.current.forEach(URL.revokeObjectURL);
    };
  }, []);

  useEffect(() => {
    let intervalId: ReturnType<typeof setInterval>;
    const checkKey = async () => {
      if (process.env.API_KEY && process.env.API_KEY.length > 0) {
        setHasApiKey(true);
        return true;
      }
      if (window.aistudio) {
          try {
             if (await window.aistudio.hasSelectedApiKey()) {
                setHasApiKey(true);
                return true;
             }
          } catch(e) { console.error(e); }
      }
      return false;
    };
    checkKey().then((found) => {
        if (!found) {
            intervalId = setInterval(async () => {
                const foundLate = await checkKey();
                if (foundLate) clearInterval(intervalId);
            }, 500);
            setTimeout(() => clearInterval(intervalId), 4000);
        }
    });
    return () => { if (intervalId) clearInterval(intervalId); };
  }, []);

  const handleApiKeySelect = async () => {
      if (window.aistudio) {
          try {
            await window.aistudio.openSelectKey();
            setHasApiKey(true);
          } catch (e) { console.error("Error selecting API key", e); }
      }
  };

  const saveStateToHistory = (state: AppHistoryState) => {
    if (isRestoringHistory.current) return;
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(state);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };

  const restoreStateFromHistory = (index: number) => {
    if (index < 0 || index >= history.length) return;
    isRestoringHistory.current = true;
    const stateToRestore = history[index];
    setImages(stateToRestore.images);
    setResults(stateToRestore.results);
    setPrompt(stateToRestore.prompt);
    setAdjustments(stateToRestore.adjustments || DEFAULT_ADJUSTMENTS);
    setMakeup(stateToRestore.makeup || DEFAULT_MAKEUP);
    setAppMode(stateToRestore.appMode || 'beauty');
    setHistoryIndex(index);
    setTimeout(() => { isRestoringHistory.current = false; }, 0);
  };
  
  const handleUndo = () => historyIndex > 0 && restoreStateFromHistory(historyIndex - 1);
  const handleRedo = () => historyIndex < history.length - 1 && restoreStateFromHistory(historyIndex + 1);

  const handleImagesSelect = (files: File[]) => {
    const newImagesData = files.map(file => {
      const url = URL.createObjectURL(file);
      objectUrlsRef.current.push(url);
      return { file, url, name: file.name };
    });
    const newImages = [...images, ...newImagesData];
    const newResults: BatchResult[] = [];
    setImages(newImages);
    setError(null);
    setResults(newResults);
    saveStateToHistory({ images: newImages, results: newResults, prompt, adjustments, makeup, appMode });
  };

  const handleImageRemove = (index: number) => {
    const newImages = [...images];
    const removed = newImages.splice(index, 1);
    if (removed[0].url.startsWith('blob:')) {
        URL.revokeObjectURL(removed[0].url);
        objectUrlsRef.current = objectUrlsRef.current.filter(url => url !== removed[0].url);
    }
    setImages(newImages);
    saveStateToHistory({ images: newImages, results, prompt, adjustments, makeup, appMode });
  };

  const handleSuggestionClick = (suggestionPrompt: string) => {
    setPrompt(suggestionPrompt);
    promptTextareaRef.current?.focus();
    saveStateToHistory({ images, results, prompt: suggestionPrompt, adjustments, makeup, appMode });
  };
  
  const handleAdjustmentChange = (key: keyof Adjustments, value: number) => {
    const newAdjustments = { ...adjustments, [key]: value };
    setAdjustments(newAdjustments);
    saveStateToHistory({ images, results, prompt, adjustments: newAdjustments, makeup, appMode });
  };

  const handleMakeupChange = (key: keyof MakeupState, value: string) => {
    const newMakeup = { ...makeup, [key]: value };
    setMakeup(newMakeup);
    saveStateToHistory({ images, results, prompt, adjustments, makeup: newMakeup, appMode });
  };

  const handleResetAdjustments = () => {
      setAdjustments(DEFAULT_ADJUSTMENTS);
      saveStateToHistory({ images, results, prompt, adjustments: DEFAULT_ADJUSTMENTS, makeup, appMode });
  };

  const handleResetMakeup = () => {
      setMakeup(DEFAULT_MAKEUP);
      saveStateToHistory({ images, results, prompt, adjustments, makeup: DEFAULT_MAKEUP, appMode });
  };

  const handleReset = () => {
    objectUrlsRef.current.forEach(URL.revokeObjectURL);
    objectUrlsRef.current = [];
    const initialState = { 
        images: [], prompt: '', results: [], adjustments: DEFAULT_ADJUSTMENTS, makeup: DEFAULT_MAKEUP, appMode: appMode 
    };
    setImages(initialState.images);
    setPrompt(initialState.prompt);
    setResults(initialState.results);
    setAdjustments(initialState.adjustments);
    setMakeup(initialState.makeup);
    setError(null);
    setIsLoading(false);
    setProcessingStatus(null);
    saveStateToHistory({ ...initialState, appMode });
  };
  
  const handleUseResultAsSource = async (resultIndex: number) => {
    const resultItem = results[resultIndex];
    if (isLoading || !resultItem?.result || resultItem.result.type !== 'image') return;
    try {
      const newFileName = `edited-${images[resultIndex].name}`;
      const newUrl = resultItem.result.content;
      const newImages = [...images];
      if (newImages[resultIndex].url.startsWith('blob:')) URL.revokeObjectURL(newImages[resultIndex].url);
      newImages[resultIndex] = { file: null, url: newUrl, name: newFileName };
      
      const newResults = results.map((res, idx) => 
        idx === resultIndex ? { originalUrl: newUrl, originalFileName: newFileName, result: null, error: null } : res
      );
      setImages(newImages);
      setResults(newResults);
      setPrompt("");
      setAdjustments(DEFAULT_ADJUSTMENTS);
      setMakeup(DEFAULT_MAKEUP);
      saveStateToHistory({ images: newImages, results: newResults, prompt: "", adjustments: DEFAULT_ADJUSTMENTS, makeup: DEFAULT_MAKEUP, appMode });
    } catch(e) { setError("Das generierte Bild konnte nicht als neue Quelle verwendet werden."); }
  };

  const handleCropSave = async (croppedImageFile: File, index: number) => {
    const newUrl = URL.createObjectURL(croppedImageFile);
    objectUrlsRef.current.push(newUrl);
    const newImages = [...images];
    if (newImages[index].url.startsWith('blob:')) URL.revokeObjectURL(newImages[index].url);
    newImages[index] = { file: croppedImageFile, url: newUrl, name: croppedImageFile.name };
    const newResults = [...results];
    if (newResults[index]) {
      newResults[index] = { ...newResults[index], originalUrl: newUrl, originalFileName: croppedImageFile.name };
    }
    setImages(newImages);
    setResults(newResults);
    saveStateToHistory({ images: newImages, results: newResults, prompt, adjustments, makeup, appMode });
    setImageToCrop(null); 
  };

  const getFullPrompt = () => {
        let fullPrompt = prompt;
        const promptParts: string[] = [];
        const hasAdjustments = Object.values(adjustments).some(val => val !== 0);
        if (hasAdjustments) {
            const adjustmentDescriptions: string[] = [];
            if (adjustments.structure !== 0) {
                 if (adjustments.structure > 0) adjustmentDescriptions.push(`STRUKTUR: Erhöhe Mikro-Kontrast (Clarity) um ${adjustments.structure * 2}%. Betone Details.`);
                 else adjustmentDescriptions.push(`STRUKTUR: Weichzeichnen um ${Math.abs(adjustments.structure * 2)}%, Kanten erhalten.`);
            }
            if (adjustments.brightness !== 0) adjustmentDescriptions.push(`Helligkeit: ${adjustments.brightness > 0 ? '+' : ''}${adjustments.brightness * 2}%`); 
            if (adjustments.contrast !== 0) adjustmentDescriptions.push(`Kontrast: ${adjustments.contrast > 0 ? '+' : ''}${adjustments.contrast * 2}%`);
            if (adjustments.saturation !== 0) adjustmentDescriptions.push(`Sättigung: ${adjustments.saturation > 0 ? '+' : ''}${adjustments.saturation * 2}%`);
            if (adjustments.vibrance !== 0) adjustmentDescriptions.push(`Dynamik: ${adjustments.vibrance > 0 ? '+' : ''}${adjustments.vibrance * 2}%`);
            if (adjustments.faceLight !== 0) adjustmentDescriptions.push(`${adjustments.faceLight > 0 ? 'Helle' : 'Dunkle'} das Gesicht um ${Math.abs(adjustments.faceLight * 2)}% ab`);
            if (adjustments.dodge !== 0) adjustmentDescriptions.push(`Dodge: ${adjustments.dodge > 0 ? '+' : ''}${adjustments.dodge}`);
            if (adjustments.burn !== 0) adjustmentDescriptions.push(`Burn: ${adjustments.burn > 0 ? '+' : ''}${adjustments.burn}`);
            promptParts.push("BILDANPASSUNGEN: " + adjustmentDescriptions.join(", ") + ".");
        }
        const hasMakeup = Object.values(makeup).some(val => val !== '');
        if (hasMakeup) {
            const makeupDescriptions: string[] = [];
            if (makeup.lipstick) makeupDescriptions.push(`Lippen: ${makeup.lipstick}`);
            if (makeup.eyeliner) makeupDescriptions.push(`Eyeliner: ${makeup.eyeliner}`);
            if (makeup.lashes) makeupDescriptions.push(`Wimpern: ${makeup.lashes}`);
            if (makeup.eyeshadow) makeupDescriptions.push(`Lidschatten: ${makeup.eyeshadow}`);
            if (makeup.blush) makeupDescriptions.push(`Rouge: ${makeup.blush}`);
            if (makeup.skin) makeupDescriptions.push(`Teint: ${makeup.skin}`);
            promptParts.push("MAKE-UP LAYER (Identität wahren!): " + makeupDescriptions.join(", ") + ".");
        }
        if (promptParts.length > 0) fullPrompt = fullPrompt ? `${fullPrompt}\n\n${promptParts.join('\n')}` : promptParts.join('\n');
        return { fullPrompt, hasAdjustments: hasAdjustments || hasMakeup };
  };

  const handleRetry = async (index: number) => {
    if (isLoading) return;
    setIsLoading(true);
    let currentResults = [...results];
    currentResults[index] = { ...currentResults[index], result: null, error: null };
    setResults(currentResults);
    setProcessingStatus(`Versuche Bild ${index + 1} erneut...`);
    const { fullPrompt, hasAdjustments } = getFullPrompt();
    const isEditRequest = hasAdjustments || EDIT_KEYWORDS.some(keyword => fullPrompt.toLowerCase().includes(keyword));
    const processingFunction = isEditRequest ? editImage : analyzeImage;
    try {
        const inputImage = images[index].file ? images[index].file! : images[index].url;
        const result = await processingFunction(inputImage, fullPrompt);
        const geminiResult: GeminiResult = isEditRequest ? { type: 'image', content: result } : { type: 'text', content: result };
        currentResults = [...currentResults];
        currentResults[index] = { ...currentResults[index], result: geminiResult, error: null };
        setResults(currentResults);
        saveStateToHistory({ images, results: currentResults, prompt, adjustments, makeup, appMode });
    } catch (e: any) {
        console.error(`Error retrying image ${index + 1}:`, e);
        const errorMessage = cleanErrorMessage(e);
        if (errorMessage.includes("Zugriff verweigert")) { setHasApiKey(false); setError(errorMessage); }
        currentResults = [...currentResults];
        currentResults[index] = { ...currentResults[index], error: errorMessage };
        setResults(currentResults);
    } finally { setIsLoading(false); setProcessingStatus(null); }
  };

  const handleSubmit = async () => {
    const { fullPrompt, hasAdjustments } = getFullPrompt();
    if (images.length === 0 || (!prompt && !hasAdjustments)) {
      setError('Bitte lade ein Bild hoch und gib einen Prompt ein.');
      return;
    }
    setIsLoading(true);
    setError(null);
    const isEditRequest = hasAdjustments || EDIT_KEYWORDS.some(keyword => fullPrompt.toLowerCase().includes(keyword));
    const processingFunction = isEditRequest ? editImage : analyzeImage;
    const initialResults: BatchResult[] = images.map(img => ({ originalUrl: img.url, originalFileName: img.name, result: null, error: null }));
    setResults(initialResults);
    let finalResults = [...initialResults];

    for (let i = 0; i < images.length; i++) {
      setProcessingStatus(`Generiere ${i + 1} von ${images.length}...`);
      try {
        const inputImage = images[i].file ? images[i].file! : images[i].url;
        const result = await processingFunction(inputImage, fullPrompt);
        const geminiResult: GeminiResult = isEditRequest ? { type: 'image', content: result } : { type: 'text', content: result };
        finalResults[i] = { ...finalResults[i], result: geminiResult };
        setResults(prev => { const updated = [...prev]; updated[i] = { ...updated[i], result: geminiResult }; return updated; });
      } catch (e: any) {
        const errorMessage = cleanErrorMessage(e);
        if (errorMessage.includes("Zugriff verweigert")) { setHasApiKey(false); setError("Zugriff verweigert."); setIsLoading(false); return; }
        finalResults[i] = { ...finalResults[i], error: errorMessage };
        setResults(prev => { const updated = [...prev]; updated[i] = { ...updated[i], error: errorMessage }; return updated; });
      }
    }
    saveStateToHistory({images, results: finalResults, prompt, adjustments, makeup, appMode});
    setIsLoading(false);
    setProcessingStatus(null);
  };

  const handleImageClick = (src: string, originalSrc?: string) => setZoomedImage({ src, originalSrc });
  const currentSuggestions = appMode === 'beauty' ? BEAUTY_CATEGORIES : CREATIVE_CATEGORIES;

  // --- DYNAMIC STYLES ---
  const mainGradient = isDarkMode
    ? (appMode === 'beauty' 
        ? 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-900 via-gray-900 to-black' 
        : 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gray-900 via-gray-900 to-black')
    : (appMode === 'beauty'
        ? 'bg-gradient-to-br from-indigo-50 via-white to-indigo-100'
        : 'bg-gradient-to-br from-pink-50 via-white to-purple-100');
  
  const accentColor = appMode === 'beauty' ? 'indigo' : 'pink';
  const accentText = isDarkMode
    ? (appMode === 'beauty' ? 'text-indigo-400' : 'text-pink-400')
    : (appMode === 'beauty' ? 'text-indigo-600' : 'text-pink-600');
    
  const cardBg = isDarkMode 
    ? 'bg-gray-800/40 backdrop-blur-md border border-white/10 shadow-xl'
    : 'bg-white/80 backdrop-blur-md border border-white/40 shadow-xl';

  const textColor = isDarkMode ? 'text-white' : 'text-gray-900';
  const mutedText = isDarkMode ? 'text-gray-400' : 'text-gray-600';
  
  const buttonActive = appMode === 'beauty' 
    ? 'bg-indigo-600 text-white shadow-[0_0_15px_rgba(79,70,229,0.4)]' 
    : 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-[0_0_15px_rgba(236,72,153,0.4)]';

  return (
    <>
      <div className={`min-h-screen ${textColor} font-sans transition-colors duration-700 ${mainGradient}`}>
        {/* Decorative Background Elements */}
        <div className={`fixed top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0`}>
             <div className={`absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full blur-[120px] opacity-20 ${appMode === 'beauty' ? 'bg-indigo-600' : 'bg-pink-600'}`}></div>
             <div className={`absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full blur-[120px] opacity-20 ${appMode === 'beauty' ? 'bg-blue-600' : 'bg-purple-600'}`}></div>
        </div>

        {/* Dark Mode Toggle */}
        <div className="absolute top-4 right-4 z-50">
          <button 
            onClick={() => setIsDarkMode(!isDarkMode)} 
            className={`p-2 rounded-full transition-colors ${isDarkMode ? 'bg-white/10 text-white hover:bg-white/20' : 'bg-black/5 text-gray-800 hover:bg-black/10'}`}
            title={isDarkMode ? 'Wechsle zu Light Mode' : 'Wechsle zu Dark Mode'}
          >
             {isDarkMode ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
             ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                </svg>
             )}
          </button>
        </div>

        <div className="relative container mx-auto max-w-7xl p-4 sm:p-6 lg:p-8 z-10">
          <header className="flex flex-col items-center mb-10">
            {/* STUDIO SWITCHER */}
            <div className={`${isDarkMode ? 'bg-black/40 border-white/5' : 'bg-white/60 border-gray-200'} backdrop-blur-lg p-1.5 rounded-full flex shadow-2xl border mb-6 transition-colors`}>
              <button
                onClick={() => setAppMode('beauty')}
                title="Wechsle zum Beauty-Modus für professionelle Retusche und Make-up"
                className={`px-8 py-2.5 rounded-full text-sm font-bold tracking-wide transition-all duration-300 ${appMode === 'beauty' ? 'bg-indigo-600 text-white shadow-lg' : (isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-900')}`}
              >
                BEAUTY STUDIO
              </button>
              <button
                onClick={() => setAppMode('creative')}
                title="Wechsle zum Creative-Modus für künstlerische Effekte und Styles"
                className={`px-8 py-2.5 rounded-full text-sm font-bold tracking-wide transition-all duration-300 ${appMode === 'creative' ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-lg' : (isDarkMode ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-900')}`}
              >
                CREATIVE FX
              </button>
            </div>
            
            <h1 className={`text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r ${appMode === 'beauty' ? (isDarkMode ? 'from-indigo-200 via-white to-indigo-200' : 'from-indigo-600 via-purple-600 to-indigo-600') : (isDarkMode ? 'from-pink-300 via-purple-300 to-indigo-300' : 'from-pink-600 via-purple-600 to-indigo-600')} mb-2 tracking-tight`}>
              PhotoStudio 21
            </h1>
            <p className={`${mutedText} text-sm tracking-widest uppercase opacity-70`}>
                Beauty & Creative FX
            </p>
          </header>

          {error && (
            <div className="bg-red-500/10 border border-red-500/50 text-red-500 px-6 py-4 rounded-xl backdrop-blur-md mb-8 shadow-[0_0_20px_rgba(239,68,68,0.1)]">
              <strong className="font-bold">System Alert: </strong>{error}
            </div>
          )}

          <main className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left Column: Tools (5 cols) */}
            <div className="lg:col-span-5 flex flex-col gap-6">
              
              {/* UPLOAD CARD */}
              <div className={`${cardBg} p-6 rounded-2xl`}>
                <ImageUploader
                  onImagesSelect={handleImagesSelect}
                  images={images}
                  onImageRemove={handleImageRemove}
                  onImageClick={(url) => handleImageClick(url)}
                  onImageCrop={(index) => setImageToCrop({ url: images[index].url, index, fileName: images[index].name })}
                  isDarkMode={isDarkMode}
                />
              </div>

              {/* CONTROL CENTER (Upper Block) */}
              <div className={`${cardBg} p-6 rounded-2xl transition-all duration-500`}>
                 <div className="mb-4">
                  <label htmlFor="prompt" className={`block text-sm font-bold uppercase tracking-wider mb-3 ${accentText}`}>
                    {appMode === 'beauty' ? 'Retusche-Anweisung' : 'Vision & Prompt'}
                  </label>
                  <textarea
                    id="prompt"
                    ref={promptTextareaRef}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder={appMode === 'beauty' ? "Beschreibe die Retusche (z.B. Haut glätten, Zähne weißen)..." : "Beschreibe den Look (z.B. Cyberpunk, Neon-Licht, wie ein Ölgemälde)..."}
                    className={`w-full h-28 p-4 border rounded-xl focus:ring-2 focus:border-transparent transition-all duration-300 resize-none placeholder-gray-500 ${isDarkMode ? 'bg-black/30 border-white/10 text-gray-200' : 'bg-white border-gray-300 text-gray-800'} ${appMode === 'beauty' ? 'focus:ring-indigo-500' : 'focus:ring-pink-500'}`}
                    disabled={isLoading}
                    title="Hier kannst du detaillierte Anweisungen eingeben"
                  />

                  {/* Tabs only for Beauty Mode */}
                  {appMode === 'beauty' && (
                    <div className={`flex mt-6 rounded-lg p-1 border ${isDarkMode ? 'bg-black/20 border-white/5' : 'bg-gray-100 border-gray-200'}`}>
                      <button onClick={() => setActivePanel('makeup')} title="Make-up Einstellungen öffnen" className={`flex-1 py-2 text-xs font-bold uppercase tracking-wide rounded-md transition-all ${activePanel === 'makeup' ? (isDarkMode ? 'bg-gray-700 text-white shadow' : 'bg-white text-gray-800 shadow') : (isDarkMode ? 'text-gray-500 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700')}`}>Make-up</button>
                      <button onClick={() => setActivePanel('adjustments')} title="Technische Bildanpassungen öffnen" className={`flex-1 py-2 text-xs font-bold uppercase tracking-wide rounded-md transition-all ${activePanel === 'adjustments' ? (isDarkMode ? 'bg-gray-700 text-white shadow' : 'bg-white text-gray-800 shadow') : (isDarkMode ? 'text-gray-500 hover:text-gray-300' : 'text-gray-500 hover:text-gray-700')}`}>Technik</button>
                    </div>
                  )}

                  {/* Panels - Only for Beauty Mode here now */}
                  <div className="mt-4">
                      {appMode === 'beauty' && (
                          activePanel === 'adjustments' ? (
                            <AdjustmentPanel values={adjustments} onChange={handleAdjustmentChange} onReset={handleResetAdjustments} disabled={isLoading} isDarkMode={isDarkMode} />
                          ) : (
                            <MakeupPanel values={makeup} onChange={handleMakeupChange} onReset={handleResetMakeup} disabled={isLoading} isDarkMode={isDarkMode} />
                          )
                      )}
                  </div>
                </div>

                {/* Actions */}
                <div className={`flex flex-col gap-3 mt-6 pt-6 border-t ${isDarkMode ? 'border-white/5' : 'border-gray-200'}`}>
                   <div className="flex gap-2">
                       <button onClick={handleUndo} title="Rückgängig" disabled={isLoading || historyIndex <= 0} className={`flex-1 p-3 rounded-xl disabled:opacity-30 border ${isDarkMode ? 'bg-gray-700/50 hover:bg-gray-600 text-white border-white/5' : 'bg-gray-100 hover:bg-gray-200 text-gray-700 border-gray-200'}`}><svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h10a8 8 0 018 8v2M3 10l6-6m-6 6l6 6" /></svg></button>
                       <button onClick={handleRedo} title="Wiederherstellen" disabled={isLoading || historyIndex >= history.length - 1} className={`flex-1 p-3 rounded-xl disabled:opacity-30 border ${isDarkMode ? 'bg-gray-700/50 hover:bg-gray-600 text-white border-white/5' : 'bg-gray-100 hover:bg-gray-200 text-gray-700 border-gray-200'}`}><svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 10H11a8 8 0 00-8 8v2m18-10l-6-6m6 6l-6 6" /></svg></button>
                       <button onClick={handleReset} title="Alles zurücksetzen" disabled={isLoading} className={`flex-1 font-bold p-3 rounded-xl disabled:opacity-30 border text-sm ${isDarkMode ? 'bg-gray-700/50 hover:bg-gray-600 text-white border-white/5' : 'bg-gray-100 hover:bg-gray-200 text-gray-700 border-gray-200'}`}>RESET</button>
                   </div>
                  
                  {!hasApiKey ? (
                      <button onClick={handleApiKeySelect} className="w-full bg-gradient-to-r from-yellow-600 to-orange-600 text-white font-bold py-4 rounded-xl shadow-lg hover:shadow-orange-500/20 transition-all flex justify-center items-center gap-2">
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 8a6 6 0 01-7.743 5.743L10 14l-1 1-1 1H6v2H2v-4l4.257-4.257A6 6 0 1118 8zm-6-4a1 1 0 100 2 2 2 0 010-2z" clipRule="evenodd" /></svg>
                         API Key aktivieren
                      </button>
                  ) : (
                    <button
                        onClick={handleSubmit}
                        disabled={isLoading || images.length === 0}
                        title="Startet die KI-Verarbeitung"
                        className={`w-full py-4 rounded-xl font-bold text-lg tracking-wide shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all disabled:opacity-50 disabled:cursor-not-allowed ${buttonActive}`}
                    >
                        {isLoading ? <span className="flex items-center justify-center gap-2"><Spinner /> {processingStatus || 'Verarbeite...'}</span> : (appMode === 'beauty' ? 'RETUSCHE STARTEN' : 'LOOK GENERIEREN')}
                    </button>
                  )}
                </div>
              </div>
              
              {/* PRESETS CARD (Lower Block) */}
              <div className={`${cardBg} p-6 rounded-2xl`}>
                <h3 className={`text-sm font-bold uppercase tracking-wider mb-4 border-b pb-2 ${accentText} ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
                    {appMode === 'beauty' ? 'Profi-Retusche Presets' : 'Creative Inspiration'}
                </h3>
                <div className="space-y-5">
                    {Object.entries(currentSuggestions).map(([category, items]) => (
                        <div key={category}>
                            <h4 className={`text-[10px] font-bold uppercase tracking-widest mb-2 ${isDarkMode ? 'text-gray-500' : 'text-gray-500'}`}>{category}</h4>
                            <div className="flex flex-wrap gap-2">
                                {items.map((suggestion) => (
                                    <button
                                        key={suggestion.name}
                                        onClick={() => handleSuggestionClick(suggestion.prompt)}
                                        disabled={isLoading}
                                        title={suggestion.prompt}
                                        className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-all duration-200 ${
                                            appMode === 'beauty' 
                                            ? (isDarkMode ? 'bg-gray-800/50 border-gray-600 text-gray-300 hover:bg-indigo-600 hover:border-indigo-500 hover:text-white' : 'bg-gray-50 border-gray-300 text-gray-700 hover:bg-indigo-100 hover:border-indigo-300 hover:text-indigo-900')
                                            : (isDarkMode ? 'bg-gray-800/50 border-gray-600 text-gray-300 hover:bg-pink-600 hover:border-pink-500 hover:text-white' : 'bg-gray-50 border-gray-300 text-gray-700 hover:bg-pink-100 hover:border-pink-300 hover:text-pink-900')
                                        }`}
                                    >
                                        {suggestion.name}
                                    </button>
                                ))}
                                {appMode === 'creative' && category.includes('Cosplay') && (
                                     <select
                                        onChange={(e) => { if (e.target.value) { handleSuggestionClick(e.target.value); e.target.value = ""; } }}
                                        className={`px-3 py-1.5 border text-xs rounded-lg cursor-pointer ${isDarkMode ? 'bg-gray-800 border-gray-600 text-gray-300 hover:border-pink-500' : 'bg-white border-gray-300 text-gray-700 hover:border-pink-300'}`}
                                        defaultValue=""
                                    >
                                        <option value="" disabled>Haare ändern...</option>
                                        {hairSuggestions.map((hair) => (<option key={hair.name} value={hair.prompt}>{hair.name}</option>))}
                                    </select>
                                )}
                            </div>
                        </div>
                    ))}
                </div>

                {/* CREATIVE MODE: MAKEUP OVERLAY MOVED HERE */}
                {appMode === 'creative' && (
                    <div className={`mt-8 pt-6 border-t ${isDarkMode ? 'border-white/10' : 'border-gray-200'}`}>
                        <div className="flex items-center gap-2 mb-4">
                            <span className="flex items-center justify-center w-5 h-5 rounded-full bg-pink-500/20 text-pink-400">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                                    <path fillRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 010 2H6v1a1 1 0 01-2 0V6H3a1 1 0 010-2h1V3a1 1 0 011-1zm0 9a1 1 0 011 1v1h1a1 1 0 110 2H6v1a1 1 0 11-2 0v-1H3a1 1 0 110-2h1v-1a1 1 0 011-1zm5-1a1 1 0 011-1h2a1 1 0 011 1v1h1a1 1 0 110 2h-1v1a1 1 0 11-2 0v-1h-2a1 1 0 110-2h1v-1z" clipRule="evenodd" />
                                </svg>
                            </span>
                            <h4 className="text-pink-400 text-xs font-bold uppercase tracking-widest">
                                Creative Makeup Overlay
                            </h4>
                        </div>
                        <div className={`rounded-xl p-3 border ${isDarkMode ? 'bg-black/20 border-white/5' : 'bg-gray-100 border-gray-200'}`}>
                            <MakeupPanel values={makeup} onChange={handleMakeupChange} onReset={handleResetMakeup} disabled={isLoading} isDarkMode={isDarkMode} />
                        </div>
                    </div>
                )}
              </div>
            </div>

            {/* Right Column: Results (7 cols) */}
            <div className={`lg:col-span-7 ${cardBg} p-1 rounded-2xl min-h-[600px] flex flex-col`}>
              <div className="p-4 flex-grow relative">
                  <ResultDisplay 
                    results={results} 
                    onImageClick={handleImageClick}
                    onUseResultAsSource={handleUseResultAsSource}
                    onSaveClick={(url, originalFileName) => setSaveModalData({ url, originalFileName })}
                    onRetry={handleRetry}
                    isDarkMode={isDarkMode}
                  />
                  {isLoading && !processingStatus && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm rounded-xl flex flex-col items-center justify-center gap-4 z-10">
                      <Spinner />
                      <p className={`${accentText} font-medium animate-pulse tracking-wide`}>Künstliche Intelligenz arbeitet...</p>
                    </div>
                  )}
              </div>
            </div>
          </main>
          
          <footer className={`mt-12 text-center text-xs ${mutedText} pb-8 opacity-60`}>
             <p>PhotoStudio 21 &copy; 2025 • Powered by Google Gemini 2.5 • Version: Shark Fix 🦈</p>
          </footer>

        </div>
      </div>
      
      {zoomedImage && <ZoomModal src={zoomedImage.src} originalSrc={zoomedImage.originalSrc} onClose={() => setZoomedImage(null)} />}
      {saveModalData && <SaveOptionsModal data={saveModalData} onClose={() => setSaveModalData(null)} />}
      {imageToCrop && <CropModal imageToCrop={imageToCrop} onClose={() => setImageToCrop(null)} onCropSave={handleCropSave} />}
    </>
  );
};

export default App;