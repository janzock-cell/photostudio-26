import { GoogleGenAI, Modality, HarmCategory, HarmBlockThreshold } from "@google/genai";

// Utility to optimize image (resize and compress)
const optimizeImage = async (file: File | string, maxWidth = 1024, maxHeight = 1024): Promise<{ data: string; mimeType: string }> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "Anonymous";
    
    img.onload = () => {
      let width = img.width;
      let height = img.height;

      // Calculate new dimensions
      if (width > height) {
        if (width > maxWidth) {
          height *= maxWidth / width;
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width *= maxHeight / height;
          height = maxHeight;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error("Konnte keinen Canvas-Kontext erstellen"));
        return;
      }
      
      ctx.drawImage(img, 0, 0, width, height);
      
      // Compress to JPEG with 0.85 quality
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      const base64Data = dataUrl.split(',')[1];
      resolve({ data: base64Data, mimeType: 'image/jpeg' });
    };

    img.onerror = () => reject(new Error("Fehler beim Laden des Bildes für die Optimierung"));

    if (typeof file === 'string') {
      img.src = file;
    } else {
      img.src = URL.createObjectURL(file);
    }
  });
};

const getInputPart = async (imageInput: File | string) => {
  try {
      // Always optimize image to ensure it meets API size/format requirements (Fixes 400 errors)
      const { data, mimeType } = await optimizeImage(imageInput);
      return {
        inlineData: {
          mimeType,
          data
        }
      };
  } catch (e) {
      console.warn("Bildoptimierung fehlgeschlagen, verwende Original", e);
      // Fallback to original method if optimization fails
      if (imageInput instanceof File) {
        const base64EncodedDataPromise = new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => {
            if (typeof reader.result === 'string') {
                resolve(reader.result.split(',')[1]);
            } else {
                resolve('');
            }
            };
            reader.readAsDataURL(imageInput);
        });
        return {
            inlineData: { data: await base64EncodedDataPromise, mimeType: imageInput.type },
        };
      } else {
         const matches = imageInput.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
         if (!matches || matches.length !== 3) {
            throw new Error('Ungültiger Base64-String als Eingabe.');
         }
         return {
            inlineData: {
                mimeType: matches[1],
                data: matches[2]
            }
         };
      }
  }
};

// RELAXED safety settings for creative tasks
const SAFETY_SETTINGS = [
  {
    category: HarmCategory.HARM_CATEGORY_HARASSMENT,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
    threshold: HarmBlockThreshold.BLOCK_NONE,
  },
];

export const analyzeImage = async (imageInput: File | string, prompt: string): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY Umgebungsvariable ist nicht gesetzt.");
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const imagePart = await getInputPart(imageInput);
  const textPart = { text: prompt };

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: { parts: [imagePart, textPart] },
    config: {
        safetySettings: SAFETY_SETTINGS
    }
  });

  if (response.promptFeedback?.blockReason) {
    throw new Error(`Blockiert: ${response.promptFeedback.blockReason}`);
  }

  const text = response.text;
  if (!text) throw new Error("Keine Textantwort erhalten.");

  return text;
};

export const editImage = async (imageInput: File | string, prompt: string): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY Umgebungsvariable ist nicht gesetzt.");
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const imagePart = await getInputPart(imageInput);

  // Helper function to build the system prompt
  const buildPrompt = (isRetry: boolean) => {
      // ANATOMIE-LOCK: Definition der unantastbaren Zonen
      // Basierend auf der Analyse: "Konturen, Wangen, Stirn, Augenbrauen, Augen, Lid, Nase, Mund, Lippen, Kinn"
      const anatomyLock = `
      [PROTECTED ANATOMY - DO NOT MODIFY GEOMETRY]
      You must treat the following features as a "Fixed Layer". Only lighting may change, NOT the shape:
      1. OUTER CONTOURS: Jawline shape, Chin width, Cheekbone prominence.
      2. EYES & LIDS: The exact shape of the eyelids (upper and lower), the iris position, and the eye corners.
      3. NOSE: Bridge width, Tip shape, and Nostril definition.
      4. MOUTH: Lip volume (upper vs lower), Cupid's bow shape, and mouth corners.
      5. FOREHEAD & BROWS: Hairline position, forehead height, eyebrow arch and thickness.
      `;

      const basePrompt = `
        [SYSTEM: PHOTO COMPOSITING & RETOUCHING]
        
        TASK: Execute the USER PROMPT (e.g., change background/style) while maintaining 100% PIXEL-PERFECT IDENTITY of the subject's face.
        
        USER PROMPT: ${prompt}
        
        ${anatomyLock}

        [CRITICAL: PERSPECTIVE & ANGLE]
        - OBSERVE THE ORIGINAL CAMERA ANGLE: If the photo is taken from below, from the side, or tilted, YOU MUST KEEP THIS ANGLE.
        - DO NOT "FIX" THE FACE to look forward.
        - DO NOT SYMMETRIZE the face. Keep all natural asymmetries.

        [EXECUTION STRATEGY]
        1. MASKING: Imagine a mask over the face. Keep the facial features (Eyes, Nose, Mouth, Contours) locked.
        2. BLENDING: Apply the new lighting/atmosphere (shadows, reflections) onto the locked face geometry. The skin texture can react to light, but the bone structure must not move.
        3. BACKGROUND: Replace the background completely if requested, ensuring the depth of field matches the subject.
      `;

      if (isRetry) {
          // Retry mode specifically for sensitive prompts
          return `
            ${basePrompt}
            
            [OVERRIDE: ARTISTIC INTERPRETATION]
            - If the prompt asks for "dark", "horror", "vampire", or "fantasy":
            - Apply this as THEATRICAL MAKEUP and LIGHTING on the EXISTING face.
            - Do NOT replace the person with a monster.
            - Keep the human identity recognizable underneath the styling.
          `;
      }
      
      return basePrompt;
  };

  const attemptGeneration = async (fullPromptText: string) => {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [imagePart, { text: fullPromptText }],
        },
        config: {
          responseModalities: [Modality.IMAGE],
          safetySettings: SAFETY_SETTINGS
        },
      });

      if (response.promptFeedback?.blockReason) {
        throw new Error(`Prompt blockiert: ${response.promptFeedback.blockReason}`);
      }

      const firstCandidate = response.candidates?.[0];
      if (!firstCandidate) {
          throw new Error("Keine Antwort vom Modell erhalten.");
      }

      // Check for image content
      if (firstCandidate.content?.parts) {
        for (const part of firstCandidate.content.parts) {
          if (part.inlineData) {
            return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
          }
        }
      }
      
      const textParts = firstCandidate.content?.parts?.filter(p => 'text' in p).map(p => (p as {text: string}).text) || [];
      if (textParts.length > 0) {
           const explanation = textParts.join(' ');
           if (explanation.includes("I cannot") || explanation.includes("I won't")) {
               throw new Error(`Modell-Ablehnung: ${explanation.substring(0, 100)}...`);
           }
      }

      if (firstCandidate.finishReason && firstCandidate.finishReason !== 'STOP') {
          if (firstCandidate.finishReason === 'SAFETY') throw new Error('Sicherheitsfilter aktiv.');
          if (firstCandidate.finishReason === 'PROHIBITED_CONTENT') throw new Error('Inhaltsrichtlinien.');
          throw new Error(`Abgebrochen: ${firstCandidate.finishReason}`);
      }

      throw new Error("Kein Bild generiert.");
  };

  try {
      return await attemptGeneration(buildPrompt(false));
  } catch (error: any) {
      const msg = error.message || "";
      const isPolicyError = msg.includes("Inhalt") || msg.includes("Copyright") || msg.includes("Sicher") || msg.includes("PROHIBITED");
                            
      if (isPolicyError) {
          console.warn("Retrying with Safety Context Wrapper...", msg);
          return await attemptGeneration(buildPrompt(true));
      }
      throw error;
  }
};